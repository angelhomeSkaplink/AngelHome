<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientMedicalInfo extends Model
{
    protected $table = 'patient_medical_info';

    protected $fillable = ['pros_id', 'doctor_id', 'medicine_name', 'quantity_of_med', 'course_date', 'frequency_in_a_day', 'time_to_take_med', 'on_monday', 'on_tuesday', 'on_wednesday','on_thursday', 'on_friday', 'on_saturday', 'on_sunday', 'date_of_prescription', 'other_instructions'];

    public $timestamps = false;
}
