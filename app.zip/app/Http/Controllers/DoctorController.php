<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\crm;
use App\PatientMedicalInfo;
use App\User;
use App\AdmissionPolicies;
use App\MedicineHistory;
use App\Medicine;
use DB, Auth;

class DoctorController extends Controller
{
	public function __construct(){
        $this->middleware('auth');
    }
	
    public function patients_list()
    {
        $patients = DB::table('sales_pipeline')->where('facility_id', Auth::user()->facility_id)
					->select('sales_pipeline.id', 'sales_pipeline.pros_name', 'sales_pipeline.contact_person', 'sales_pipeline.phone_p', 'sales_pipeline.city_p')
                    ->get();

        return view('doctor.patients_list', compact('patients'));
    }

    public function add_patient_details($id)
    {
		$medicines = DB::table('medicine')->where('facility_id', Auth::user()->facility_id)->get();
        return view('doctor.add_patient_details', compact('id', 'medicines'));
    }

    public function store_patient_medical_info(Request $request)
    {
		if($request['medicine_name'] == "add"){
			
			$new_medicine = new Medicine();
			$new_medicine->medicine_name = $request['med_name'];
			$new_medicine->facility_id = Auth::user()->facility_id;
			$new_medicine->save();
			
			$new_data = new PatientMedicalInfo();
			$new_data->pros_id = $request['pros_id'];
			$new_data->date_of_prescription = $request['date_of_prescription'];
			$new_data->medicine_name = $request['med_name'];
			$new_data->quantity_of_med = $request['quantity_of_med'];
			$new_data->course_date = $request['course_date'];
			$new_data->frequency_in_a_day = $request['frequency_in_a_day'];
			$new_data->time_to_take_med = $request['time_to_take_med'];
			$new_data->on_monday = $request['on_monday'];
			$new_data->on_tuesday = $request['on_tuesday'];
			$new_data->on_wednesday = $request['on_wednesday'];
			$new_data->on_thursday = $request['on_thursday'];
			$new_data->on_friday = $request['on_friday'];
			$new_data->on_saturday = $request['on_saturday'];
			$new_data->on_sunday = $request['on_sunday'];
			$new_data->other_instructions = $request['other_instructions'];
			$new_data->save();
		}else{
			$new_data = new PatientMedicalInfo();
			$new_data->pros_id = $request['pros_id'];
			$new_data->date_of_prescription = $request['date_of_prescription'];
			$new_data->medicine_name = $request['medicine_name'];
			$new_data->quantity_of_med = $request['quantity_of_med'];
			$new_data->course_date = $request['course_date'];
			$new_data->frequency_in_a_day = $request['frequency_in_a_day'];
			$new_data->time_to_take_med = $request['time_to_take_med'];
			$new_data->on_monday = $request['on_monday'];
			$new_data->on_tuesday = $request['on_tuesday'];
			$new_data->on_wednesday = $request['on_wednesday'];
			$new_data->on_thursday = $request['on_thursday'];
			$new_data->on_friday = $request['on_friday'];
			$new_data->on_saturday = $request['on_saturday'];
			$new_data->on_sunday = $request['on_sunday'];
			$new_data->other_instructions = $request['other_instructions'];
			$new_data->save();
		}
        return redirect('view_patient_details/'.$request['pros_id']);
    }

    public function view_patient_details($id)
    {
        $qry_data = DB::table('patient_medical_info')
                    ->Join('sales_pipeline', 'sales_pipeline.id', '=', 'patient_medical_info.pros_id')
                    ->select('patient_medical_info.*')
                    ->where('patient_medical_info.pros_id', $id)
                    ->orderBy('patient_medical_info.pat_medi_id', 'DESC')
                    ->get();

        return view('doctor.view_patient_details', compact('qry_data', 'id'));
    }

    public function delete_records($pat_medi_id, $pros_id)
    {
        DB::table('patient_medical_info')
        ->where('pat_medi_id', '=', $pat_medi_id)
        ->delete();

        return redirect('view_patient_details/'.$pros_id);
    }

    // ***** Controller for admission policies
    public function create_policy()
    {
        return view('admission_policies.create_policy');
    }

    public function store_policy_details(Request $request)
    {
        $all_data = array(
            'policy_title' => $request['policy_title'],
            'policy_desc' => $request['policy_description'],
            'pol_effected_date' => $request['pol_effected_date'],
            'policy_status' => 1,
            'facility_id' => 1,
            'user_id' => Auth::user()->user_id,
            'date_of_add' => date("Y-m-d",time()),
        );

        DB::table('admission_policies')
            ->where('policy_status', 1)
            ->update(['policy_status' => 0]);

        $new_data = new AdmissionPolicies();
        $new_data->policy_title = $all_data['policy_title'];
        $new_data->policy_desc = $all_data['policy_desc'];
        $new_data->pol_effected_date = $all_data['pol_effected_date'];
        $new_data->policy_status = $all_data['policy_status'];
        $new_data->facility_id = $all_data['facility_id'];
        $new_data->user_id = $all_data['user_id'];
        $new_data->date_of_add = $all_data['date_of_add'];
        $new_data->save();

        // return view('admission_policies.view_policy');
        return redirect('view_policy');
        // dd($all_data);
    }

    public function edit_policy()
    {
        $qry_data = DB::table('admission_policies')
                    ->select('admission_policies.*')
                    ->where('admission_policies.policy_status', 1)
                    ->get();

        return view('admission_policies.edit_policy', compact('qry_data'));
    }

    public function update_policy(Request $request)
    {
        DB::table('admission_policies')
            ->where('policy_status', 1)
            ->update([
                'policy_title' => $request['policy_title'],
                'policy_desc' => $request['policy_desc'],
                'pol_effected_date' => $request['pol_effected_date'],
            ]);

        return redirect('view_policy');
    }

    public function view_policy()
    {
        $qry_data = DB::table('admission_policies')
                    ->select('admission_policies.*')
                    ->where('admission_policies.policy_status', 1)
                    ->get();

        return view('admission_policies.view_policy', compact('qry_data'));
        // dd($qry_data);
    }

    // Finished from Nilutpal

	public function patient_medicine(){

		$current_date = date("Y-m-d",time());
		$medicines = DB::table('patient_medical_info')
						->where('patient_medical_info.date_of_prescription', '<=', $current_date)
						->where('patient_medical_info.course_date', '>=', $current_date)
						->Join('sales_pipeline', 'patient_medical_info.pros_id', '=', 'sales_pipeline.id')
						->where('facility_id', Auth::user()->facility_id)
						->select('sales_pipeline.*', 'patient_medical_info.*');
		$medicines = $medicines->paginate(6);
		return view('doctor.medicin_info_view', compact('medicines', 'current_date'));
	}

	public function add_history($pat_medi_id)
    {
        $medicinehistory = new MedicineHistory();
        $medicinehistory->pat_medi_id = $pat_medi_id;
		$medicinehistory->history_date = date("Y-m-d",time());
		$medicinehistory->user_id = Auth::user()->user_id;
        $medicinehistory->facility_id = Auth::user()->facility_id;
        $medicinehistory->save();
        return redirect('/patient_medicine');
    }

}
