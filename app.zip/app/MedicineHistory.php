<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MedicineHistory extends Model
{
    protected $table = 'medicine_history';
    protected $fillable = ['pat_medi_id', 'history_date', 'user_id', 'facility_id'];
    public $timestamps = false;
}
