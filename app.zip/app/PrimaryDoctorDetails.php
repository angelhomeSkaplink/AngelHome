<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrimaryDoctorDetails extends Model
{
    protected $table = 'primary_doctor_details';

    protected $fillable = ['pros_id', 'primary_doctor_primary', 'address1_primary', 'address2_primary', 'city_primary', 'state_primary', 
	'zipcode_primary', 'phone_primary_doctor'. 'medical_diagnosis', 'other_m_p_prob_primary', 'email_primary_doctor', 'fax_primary_doctor', 'date', 'user_id', 'status'];

    public $timestamps = false;
}
