
@extends('layouts.app')

@section('htmlheader_title')
    Prospective Info 
@endsection

@section('contentheader_title')
    Resident ASSESSMENT
@endsection

@section('main-content')
<style>
	.wickedpicker{
		z-index:999 !important;
	}
	.content-header
	{
		//display:none;
		padding: 2px 0px 1px 20px;
		margin-bottom: -10px;
	}
	.content {
		margin-top: 15px;
	}
</style>
<div class="row">
    <div class="col-md-12">
        <div class="box box-primary border">
				
            <div class="box-body border padding-top-0 padding-left-right-0">
                <table class="table">
                    <tbody>
						<tr>
								
							<th class="th-position text-uppercase font-400 font-13">#</th>
							<th class="th-position text-uppercase font-500 font-12">Resident</th>
							<th class="th-position text-uppercase font-500 font-12">Phone No</th>
							<th class="th-position text-uppercase font-500 font-12">Select Resident</th>								
							<th class="th-position text-uppercase font-500 font-12">assessment history</th>
							<th class="th-position text-uppercase font-500 font-12">Next assessment DATe</th>
						</tr>
						@foreach ($crms as $crm)
						<tr>
							<input type="hidden" class="form-control" value="{{ $crm->id }}" name="id"/>
							@if($crm->service_image == NULL)
							<td><img src="hsfiles/public/img/538642-user_512x512.png" class="img-circle" width="40" height="40"></td>	
							@else
							<td><img src="hsfiles/public/img/{{ $crm->service_image }}" class="img-circle" width="40" height="40"></td>
							@endif
							<td>{{ $crm->pros_name }}</td>
							<?php 
								$basic = DB::table('change_pross_record')->where([['pros_id', $crm->id], ['status', 1]])->first();{
							?>
							<td>{{ $basic->phone_p }}</td>
							<?php } ?>								
							<input type="hidden" id="csrf" name="_token" value="{{ csrf_token() }}">
							<td class="padding-left-45">
								<a href="select_assessments/{{ $crm->id}}" class="material-icons material-icons gray md-22" style="background:transparent; border:none">check_circle </button>
							</td>
							<td class="padding-left-45">
								<a href="assessment_history/{{ $crm->id}}" class="material-icons material-icons gray md-22" style="background:transparent; border:none">history </button>
							</td>
							<?php
								$status = DB::table('resident_assessment')->where([['pros_id', $crm->id], ['resident_assessment.assessment_status', 1]])->first();
								if(!$status){
							?>
							<td class="text-danger"><b>NO ASSESSMENT DONE</b></td>
							<?php } else{
								$today = date("Y-m-d");
								$next_date = DB::table('next_assessment')->where([['pros_id', $crm->id], ['next_assessment.assessment_status', 1]])->first();
								if(!$next_date){
							?>
							<td class="text-danger"><b>NO NEXT ASSESSMENT DATE FOUND</b></td>
							<?php } else{
								$max_date = $next_date->next_assessment_date;
								$diff = date_diff(date_create($max_date),date_create($today));
								$diff = $diff->days;
								if($diff>=30){
							?>
							<td class="text-success"><b>NEXT ASSESSMENT DATE = {{ $next_date->next_assessment_date }}</b></td>
							<?php }elseif($diff<30 && $diff>0){ ?>
							<td class="text-warning"><b>NEXT ASSESSMENT DATE = {{ $next_date->next_assessment_date }}</b></td>
							<?php } elseif($diff==0){?>
							<td class="text-danger"><b>NEXT ASSESSMENT DATE = {{ $next_date->next_assessment_date }}</b></td>
							<?php } } } ?>
						</tr>
						@endforeach
                    </tbody>
				</table>
				<div class="text-center">{{ $crms->links() }}</div>
            </div>                
        </div>
    </div>
</div>
@endsection
@section('scripts-extra')

@endsection